#Thresholding  using cv2,matplotlib.pylab and numpy
import cv2 as cv
import numpy as np
import matplotlib.pylab as plt
#read the image
img=cv.imread("E:\IPMV images\light1.jpg",0)
#img=cv.cvtColor(img,cv.COLOR_BGR2RGB)
#show the img
plt.subplot(1,6,1)
plt.title('original image')
plt.imshow(img,cmap='gray')

#using opencv instruction
a,img2=cv.threshold(img,107,255,0)
#showing result
plt.subplot(1,6,2)
plt.title('Threshold Img')
plt.imshow(img2,cmap='gray')

b,img2=cv.threshold(img,107,255,1)
plt.subplot(1,6,3)
plt.title('Threshold Img2')
plt.imshow(img2,cmap='gray')

c,img2=cv.threshold(img,107,255,2)
plt.subplot(1,6,4)
plt.title('Threshold Img3')
plt.imshow(img2,cmap='gray')

c,img2=cv.threshold(img,107,255,3)
plt.subplot(1,6,5)
plt.title('Threshold Img3')
plt.imshow(img2,cmap='gray')

d,img2=cv.threshold(img,107,255,4)
plt.subplot(1,6,6)
plt.title('Threshold Img4')
plt.imshow(img2,cmap='gray')
plt.show()

