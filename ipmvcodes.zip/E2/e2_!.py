#contrast modification
import cv2 as cv

img=cv.imread("E:\IPMV images\light1.jpg",0)
cv.imshow("Original img",img)
s=img.size
print('size of image=',s)
print('shape of image=',img.shape)
lt=200
ut=250
a=0.02
b=2

for i in range(441):
    for y in range(300):
        if(i,y < lt):
            img[i,y]=img[i,y]*a
        elif(i,y<ut):
            img[i,y]=b*(img[i,y]-lt) + (a*lt)
        else:
            img[i,y]=a*[img[i,y]-ut]+(a*lt) +b*(ut-lt)
newimg=img
cv.imshow('Modified Img Brightness',newimg)
cv.waitKey(0)
cv.destroyAllWindows()
