#contrast modification using cv2 and numpy
import cv2 as cv
import numpy as np

img=cv.imread("E:\IPMV images\cameraman.png")
cv.imshow("Original img",img)
s=img.size
print('size of image=',s)
print('shape of image=',img.shape)

img2=np.zeros(img.shape,img.dtype)
contrast=0.5

for i in range(img2.shape[0]):
    for y in range(img2.shape[1]):
        for z in range(img2.shape[2]):
            img2[i,y,z]=np.clip(contrast*img[i,y,z],0,255)
     
newimg=img2
cv.imshow('Modified Img Brightness',newimg)
cv.waitKey(0)
cv.destroyAllWindows()
