import cv2 as cv


img=cv.imread("E:\IPMV images\light1.jpg")
cv.imshow("Original img",img)
s=img.size
print('size of image=',s)
print('shape of image=',img.shape)
lt=120
ut=210
a=0.6
b=2

for i in range(441):
    for y in range(300):
        for z in range(3):
            if(i,y,z < lt):
                img[i,y,z]=img[i,y,z]*a
            elif(i,y<ut):
                img[i,y,z]=b*(img[i,y,z]-lt) + (a*lt)
            else:
                img[i,y,z]=a*[img[i,y,z]-ut]+(a*lt) +b*(ut-lt)
newimg=img
cv.imshow('Modified Img Brightness',newimg)
cv.waitKey(0)
cv.destroyAllWindows()
