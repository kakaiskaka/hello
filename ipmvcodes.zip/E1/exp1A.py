print('welcome')
for i in range(10):
    print(i)
print("end of program")
